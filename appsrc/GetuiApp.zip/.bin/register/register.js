(function() {
	/*
	 * APICloud JavaScript Library
	 * Copyright (c) 2014 apicloud.com
	 */
	var $kn = {
		byId: function byId(id) {
			return document.getElementById(id);
		},
		ajax: function ajax(p, callback) {
			var _this = this;
			var param = p;
			if (!param.headers) {
				param.headers = {};
			}
			param.headers["x-apicloud-mcm-key"] = "cZKzX7DabDmYyfez";
			if (param.data && param.data.body) {
				param.headers["Content-Type"] = "application/json; charset=utf-8";
			}
			if (param.url) {
				var baseUrl = "http://10.10.66.31:8080/";
				param.url = baseUrl + param.url;
				console.log("url----" + param.url);
			}
			api.ajax(param, function(ret, err) {
				if (callback) callback(ret, err);
				if (ret) {
					var status = ret.status;
					if (status && status == 4001) {
						var didShowLogoutAlert = api.getGlobalData({
							key: "didShowLogoutAlert"
						});

						if (!didShowLogoutAlert) {
							api.setGlobalData({
								key: "didShowLogoutAlert",
								value: true
							});

							_this.setUserInfo("");
							api.alert(
								{
									msg: "登录已失效，请重新登录"
								},
								function() {
									api.setGlobalData({
										key: "didShowLogoutAlert",
										value: false
									});

									api.closeToWin({
										name: "root"
									});
								}
							);
						}
					}
				}
			});
		},
		getUserInfo: function getUserInfo() {
			var value = api.getPrefs({
				key: "userInfo",
				sync: true
			});

			return value ? JSON.parse(value) : "";
		},
		setUserInfo: function setUserInfo(userInfo) {
			api.setPrefs({
				key: "userInfo",
				value: userInfo
			});
		},
		getCurrentCityInfo: function getCurrentCityInfo() {
			var value = api.getPrefs({
				key: "currentCity",
				sync: true
			});

			return value ? JSON.parse(value) : "";
		},
		setCurrentCityInfo: function setCurrentCityInfo(cityInfo) {
			api.setPrefs({
				key: "currentCity",
				value: cityInfo
			});
		},
		getWareTypeList: function getWareTypeList() {
			var value = api.readFile({
				sync: true,
				path: "fs://WareTypeList"
			});

			return value ? JSON.parse(value) : "";
		},
		setWareTypeList: function setWareTypeList(list) {
			api.writeFile({
				path: "fs://WareTypeList",
				data: JSON.stringify(list)
			});
		},
		fitRichText: function fitRichText(richtext, width) {
			var str = '<img style="max-width:' + width + 'px;"';
			var result = richtext.replace(/\<img/gi, str);
			return result;
		}
	};

	var StatusBarView = /*@__PURE__*/ (function(Component) {
		function StatusBarView(props) {
			Component.call(this, props);
			this.compute = {
				statusBarHeight: function() {
					if (api.safeArea) {
						return api.safeArea.top;
					} else {
						var res = wx.getSystemInfoSync();
						return res.statusBarHeight;
					}
				}
			};
		}

		if (Component) StatusBarView.__proto__ = Component;
		StatusBarView.prototype = Object.create(Component && Component.prototype);
		StatusBarView.prototype.constructor = StatusBarView;
		StatusBarView.prototype.render = function() {
			return apivm.h("view", {style: "height:" + this.statusBarHeight + "px;"});
		};

		return StatusBarView;
	})(Component);
	apivm.define("status-bar-view", StatusBarView);

	var Navigationbar = /*@__PURE__*/ (function(Component) {
		function Navigationbar(props) {
			Component.call(this, props);
		}

		if (Component) Navigationbar.__proto__ = Component;
		Navigationbar.prototype = Object.create(Component && Component.prototype);
		Navigationbar.prototype.constructor = Navigationbar;
		Navigationbar.prototype.onLeftButton = function(e) {
			api.closeWin();
		};
		Navigationbar.prototype.render = function() {
			return apivm.h(
				"view",
				{class: "nav-container"},
				apivm.h("status-bar-view", null),
				apivm.h(
					"view",
					{class: "nav-header"},
					apivm.h(
						"view",
						{
							class: "nav-header-button nav-left-button",
							onclick: this.props.onLeftButton
								? this.props.onLeftButton
								: this.onLeftButton
						},
						apivm.h("image", {
							width: this.props.leftButtonWidth ? this.props.leftButtonWidth : 11,
							src: this.props.leftButtonIcon
								? this.props.leftButtonIcon
								: "../../image/back.png",
							mode: "widthFix"
						}),
						apivm.h("text", {class: "nav-header-text"}, this.props.leftButtonText)
					),
					apivm.h("text", {class: "nav-header-title"}, this.props.title),
					apivm.h(
						"view",
						{
							class: "nav-header-button nav-right-button",
							onclick: this.props.onRightButton
						},
						apivm.h("image", {
							width: this.props.rightButtonWidth ? this.props.rightButtonWidth : 0,
							src: this.props.rightButtonIcon ? this.props.rightButtonIcon : "",
							mode: "widthFix"
						}),
						apivm.h("text", {class: "nav-header-text"}, this.props.rightButtonText)
					)
				)
			);
		};

		return Navigationbar;
	})(Component);
	Navigationbar.css = {
		".nav-container": {backgroundColor: "#e3007f"},
		".nav-header": {
			flexDirection: "row",
			alignItems: "center",
			justifyContent: "space-between",
			width: "100%",
			height: "44px"
		},
		".nav-header-title": {color: "#fff", fontSize: "18px", fontWeight: "bold"},
		".nav-header-button": {
			flexDirection: "row",
			alignItems: "center",
			minWidth: "44px",
			height: "100%"
		},
		".nav-header-button:active": {opacity: "0.5"},
		".nav-left-button": {justifyContent: "flex-start", paddingLeft: "10px"},
		".nav-right-button": {justifyContent: "flex-end", paddingRight: "10px"},
		".nav-header-text": {color: "#fff", fontSize: "17px"}
	};
	apivm.define("navigationBar", Navigationbar);

	var Register = /*@__PURE__*/ (function(Component) {
		function Register(props) {
			Component.call(this, props);
			this.data = {};
		}

		if (Component) Register.__proto__ = Component;
		Register.prototype = Object.create(Component && Component.prototype);
		Register.prototype.constructor = Register;
		Register.prototype.apiready = function() {
			document.getElementById("username").focus();
		};
		Register.prototype.fnRegister = function() {
			var that = this;
			var usernameValue = document.getElementById("username").value;
			var passwordValue = document.getElementById("password").value;
			var confirmpasswordValue = document.getElementById("confirmpassword").value;
			if (!usernameValue) {
				this.toast("请输入用户名");
				return;
			}
			if (!passwordValue) {
				this.toast("请输入密码");
				return;
			}
			if (passwordValue.length < 6 || passwordValue.length > 12) {
				this.toast("密码格式不正确");
				return;
			}
			if (!confirmpasswordValue) {
				this.toast("请输入确认密码");
				return;
			}
			if (passwordValue != confirmpasswordValue) {
				this.toast("两次输入密码不一致");
				return;
			}

			$kn.ajax(
				{
					url: "users/register",
					method: "post",
					data: {
						body: {
							username: usernameValue,
							password: passwordValue
						}
					}
				},

				function(ret, err) {
					if (ret) {
						if (ret.data) {
							// 保存用户信息
							$kn.setUserInfo(ret.data);

							that.toast("注册成功");

							var windows = api.windows();
							for (var i = 0; i < windows.length; i++) {
								if (windows[i].name == "login") {
									api.closeToWin({
										name: windows[i - 1].name
									});
								}
							}
						} else if (ret.status == 4002) {
							that.toast("用户名已被占用");
						} else {
							that.toast("注册失败");
						}
					} else {
						that.toast("网络错误");
					}
				}
			);
		};
		Register.prototype.toast = function(msg) {
			api.toast({
				msg: msg,
				location: "middle",
				global: true
			});
		};
		Register.prototype.render = function() {
			return apivm.h(
				"view",
				{class: "main"},
				apivm.h("navigationBar", {title: "会员注册"}),
				apivm.h(
					"scroll-view",
					{class: "scrollView", "scroll-y": "true"},
					apivm.h(
						"view",
						{class: "container"},
						apivm.h("input", {id: "username", class: "input", placeholder: "用户名"}),
						apivm.h("input", {
							id: "password",
							class: "input",
							type: "password",
							placeholder: "6~12位密码"
						}),
						apivm.h("input", {
							id: "confirmpassword",
							class: "input",
							type: "password",
							placeholder: "确认密码"
						}),
						apivm.h("text", {class: "btn", onclick: this.fnRegister}, "注册")
					)
				)
			);
		};

		return Register;
	})(Component);
	Register.css = {
		".main": {width: "100%", height: "100%"},
		".scrollView": {flex: "1"},
		".container": {padding: "20px"},
		".input": {
			width: "100%",
			height: "40px",
			marginBottom: "30px",
			border: "none",
			borderBottom: "1px solid #ddd"
		},
		".btn": {
			height: "50px",
			backgroundColor: "#e3007f",
			lineHeight: "50px",
			color: "#fff",
			fontSize: "24px",
			textAlign: "center",
			borderRadius: "8px"
		},
		".btn:active": {opacity: "0.8"}
	};
	apivm.define("register", Register);
	apivm.render(apivm.h("register", null), "body");
})();
