var citys = [{
    "name": "北京市",
    "sub": [{
        "name": "东城区"
    }, {
        "name": "西城区"
    }, {
        "name": "海淀区"
    }, {
        "name": "朝阳区"
    }, {
        "name": "丰台区"
    }, {
        "name": "石景山区"
    }, {
        "name": "昌平区"
    }, {
        "name": "通州区"
    }]
}, {
    "name": "河南省",
    "sub": [{
        "name": "郑州市",
        "sub": [{
            "name": "中原区"
        }, {
            "name": "金水区"
        }]
    }, {
        "name": "驻马店市",
        "sub": [{
            "name": "西平县"
        }, {
            "name": "泌阳县"
        }]
    }]
}]

export default citys;
