
function getCid(){
  return $api.getStorage('cid');
}
function setCid(val = ''){
  $api.setStorage('cid', val);
}